
minetest.register_node("letterblocks:An", {
    description = "Letter Block",
    tiles = {"A-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Bn", {
    description = "Letter Block",
    tiles = {"B-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Cn", {
    description = "Letter Block",
    tiles = {"C-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Dn", {
    description = "Letter Block",
    tiles = {"D-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:En", {
    description = "Letter Block",
    tiles = {"E-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Fn", {
    description = "Letter Block",
    tiles = {"F-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Gn", {
    description = "Letter Block",
    tiles = {"G-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Hn", {
    description = "Letter Block",
    tiles = {"H-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:In", {
    description = "Letter Block",
    tiles = {"I-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Jn", {
    description = "Letter Block",
    tiles = {"J-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Kn", {
    description = "Letter Block",
    tiles = {"K-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Ln", {
    description = "Letter Block",
    tiles = {"L-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Mn", {
    description = "Letter Block",
    tiles = {"M-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Nn", {
    description = "Letter Block",
    tiles = {"N-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:On", {
    description = "Letter Block",
    tiles = {"O-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Pn", {
    description = "Letter Block",
    tiles = {"P-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Qn", {
    description = "Letter Block",
    tiles = {"Q-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Rn", {
    description = "Letter Block",
    tiles = {"R-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Sn", {
    description = "Letter Block",
    tiles = {"S-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Tn", {
    description = "Letter Block",
    tiles = {"T-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Un", {
    description = "Letter Block",
    tiles = {"U-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Vn", {
    description = "Letter Block",
    tiles = {"V-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Wn", {
    description = "Letter Block",
    tiles = {"W-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Xn", {
    description = "Letter Block",
    tiles = {"X-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Yn", {
    description = "Letter Block",
    tiles = {"Y-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Zn", {
    description = "Letter Block",
    tiles = {"Z-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:1n", {
    description = "Number Block",
    tiles = {"1-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:2n", {
    description = "Number Block",
    tiles = {"2-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:3n", {
    description = "Number Block",
    tiles = {"3-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:4n", {
    description = "Number Block",
    tiles = {"4-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:5n", {
    description = "Number Block",
    tiles = {"5-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:6n", {
    description = "Number Block",
    tiles = {"6-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:7n", {
    description = "Number Block",
    tiles = {"7-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:8n", {
    description = "Number Block",
    tiles = {"8-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:9n", {
    description = "Number Block",
    tiles = {"9-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:0n", {
    description = "Number Block",
    tiles = {"0-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, number=1}
})

minetest.register_node("letterblocks:excln", {
    description = "Symbol Block",
    tiles = {"excl-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:quesn", {
    description = "Symbol Block",
    tiles = {"ques-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1},
	drop = "flowers:mushroom_brown"
})

minetest.register_node("letterblocks:plusn", {
    description = "Symbol Block",
    tiles = {"plus-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:minusn", {
    description = "Symbol Block",
    tiles = {"minus-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:timesn", {
    description = "Symbol Block",
    tiles = {"times-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:divn", {
    description = "Symbol Block",
    tiles = {"div-n.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:error", {
    description = "Error block",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.375, -0.4375, -0.4375, 0.375, 0.4375, 0.4375}, -- NodeBox1
			{-0.4375, -0.4375, -0.375, 0.4375, 0.4375, 0.375}, -- NodeBox2
			{-0.4375, -0.375, -0.4375, 0.4375, 0.375, 0.4375}, -- NodeBox3
			{-0.25, -0.5, -0.25, 0.25, 0.5, 0.25}, -- NodeBox4
			{-0.5, -0.25, -0.25, 0.5, 0.25, 0.25}, -- NodeBox5
			{-0.25, -0.25, -0.5, 0.25, 0.25, 0.5}, -- NodeBox6
		}
	},
	on_punch = function(pos)
	
	end,
    tiles = {"huh.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1, not_in_creative_inventory=1},
	drop = "air"
})

minetest.register_node("letterblocks:Space", {
    description = "Letter Block",
	drawtype = "glasslike_framed",
    tiles = {"Space-n.png","Space-d.png"},
    is_ground_content = false,
    groups = {snappy=3, stone=1}
})

minetest.register_node("letterblocks:Lettermaker", {
    description = "Letter Block Constructor",
	drawtype = "nodebox",
	tiles = {
		"LM-t.png",
		"LM-b.png",
		"LM-s.png",
		"LM-n.png",
		"LM-e.png",
		"LM-w.png"
	},
    node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.25, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0, 0.5, 0.5} -- NodeBox2
		}
	},
    is_ground_content = false,
    groups = {snappy=3, stone=1},
	after_place_node = function(pos, placer)
        local meta = minetest.get_meta(pos)
        meta:set_string("formspec",
                "size[8,9]"..
                "label[1,0;Letter Block Constructor]"..
				"label[5,0;Use Capital Letters\nUse \"excl\" for !\nUse \"ques\" for ?\nSee reference book for other symbols]"..
				"label[1,3;Input]"..
				"label[6,3;Output]"..
                "field[2,1;1,1;a;Letter;]"..
				"button[3,0;2,1;x;Print Letter onto Block]"..
				"list[context;input;1,2;1,1]"..
				"list[context;output;6,2;1,1]"..
				"list[current_player;main;0,5;8,4;]")
		local inv = meta:get_inventory()
		inv:set_size("input",1)
		inv:set_size("output",1)
    end,
	on_receive_fields = function(pos, formname, fields, player)
		local stack = ItemStack("letterblocks:Space")
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		if inv:contains_item("input",stack) and fields.a ~= nil then
			local stack2 = ItemStack("letterblocks:"..fields.a.."n")
			inv:add_item("output",stack2)
			inv:remove_item("input",stack)
		end
    end
})

minetest.register_craftitem("letterblocks:Futurepaint",{
	description = "Futuristic Paint",
	inventory_image = "Comp-a.png"
})

minetest.register_craftitem("letterblocks:bookn",{
	description = "Book of Futuristic Letters",
	inventory_image = "Comp-b.png",
	groups = {book=1},
	on_use = function(itemstack, user, pointed_thing)
		local n = user:get_player_name()
		minetest.show_formspec(n,"letterblocks:book",
		"size[6,9]"..
		"image[-0.625,-1.875;9,13.5;Book.png]")
	end
})

minetest.register_craft({
	output = "letterblocks:Lettermaker",
	recipe = {
		{"default:stonebrick","default:stonebrick","default:stonebrick"},
		{"letterblocks:Futurepaint","","letterblocks:Futurepaint"},
		{"default:stonebrick","default:stonebrick","default:stonebrick"}
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "letterblocks:Futurepaint",
	recipe = {"dye:green","bucket:bucket_water","default:stick"},
	replacements = {{"default:stick","default:stick"}}
})

minetest.register_craft({
	type = "shapeless",
	output = "letterblocks:Space 16",
	recipe = {"letterblocks:Futurepaint","default:stonebrick"},
	replacements = {{"letterblocks:Futurepaint","letterblocks:Futurepaint"}}
})

minetest.register_craft({
	output = "letterblocks:error",
	recipe = {
		{"group:number"},
		{"letterblocks:divn"},
		{"letterblocks:0n"}
	}
})	

minetest.register_craft({
	type = "shapeless",
	output = "letterblocks:bookn",
	recipe = {"letterblocks:Futurepaint","default:book"},
	replacements = {{"letterblocks:Futurepaint","letterblocks:Futurepaint"}}
})






















