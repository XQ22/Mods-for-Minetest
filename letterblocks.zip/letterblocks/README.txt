XQ22's Letter Blocks mod
========================

Adds printable blocks for making signs and space-age style lettering. There may be a few easter eggs inside.

Version: 1.0 
Licence: CC0
Dependencies: dye, default, bucket

Installation
------------

Unzip the archive, rename the folder to "letterblocks" and place it in minetest/mods/

For further information or help see:
http://wiki.minetest.com/wiki/Installing_Mods